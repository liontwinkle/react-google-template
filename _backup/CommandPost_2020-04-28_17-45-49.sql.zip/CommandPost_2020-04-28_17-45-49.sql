-- MySQL dump 10.14  Distrib 5.5.64-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: CommandPost
-- ------------------------------------------------------
-- Server version	5.5.64-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `CommandPost`
--


--
-- Table structure for table `cp_apps`
--

DROP TABLE IF EXISTS `cp_apps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cp_apps` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `application_title` varchar(256) DEFAULT NULL,
  `application_active` int(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `id_2` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cp_apps`
--

LOCK TABLES `cp_apps` WRITE;
/*!40000 ALTER TABLE `cp_apps` DISABLE KEYS */;
INSERT INTO `cp_apps` VALUES (1,'Dashboard',1),(2,'Incident Logging',1),(3,'Contact List',1),(4,'File Manager',0),(5,'Resource Positioning',0),(6,'Fleet Management',0),(7,'Accreditation',0),(8,'Scheduling',0);
/*!40000 ALTER TABLE `cp_apps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cp_event_apps`
--

DROP TABLE IF EXISTS `cp_event_apps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cp_event_apps` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_event` int(11) DEFAULT NULL,
  `id_app` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cp_event_apps`
--

LOCK TABLES `cp_event_apps` WRITE;
/*!40000 ALTER TABLE `cp_event_apps` DISABLE KEYS */;
INSERT INTO `cp_event_apps` VALUES (1,1,1),(2,1,2),(3,1,3),(4,1,4),(5,1,5);
/*!40000 ALTER TABLE `cp_event_apps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cp_event_instances`
--

DROP TABLE IF EXISTS `cp_event_instances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cp_event_instances` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_event` int(11) DEFAULT NULL,
  `id_instance` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cp_event_instances`
--

LOCK TABLES `cp_event_instances` WRITE;
/*!40000 ALTER TABLE `cp_event_instances` DISABLE KEYS */;
INSERT INTO `cp_event_instances` VALUES (1,1,1),(2,1,2),(3,1,3),(4,1,4),(5,1,5),(6,2,6);
/*!40000 ALTER TABLE `cp_event_instances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cp_event_loggers`
--

DROP TABLE IF EXISTS `cp_event_loggers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cp_event_loggers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) DEFAULT NULL,
  `id_event` int(11) DEFAULT NULL,
  `event_user_role` varchar(128) DEFAULT NULL,
  `event_user_company` varchar(128) DEFAULT NULL,
  `user_contact_number` varchar(128) DEFAULT NULL,
  `user_type` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cp_event_loggers`
--

LOCK TABLES `cp_event_loggers` WRITE;
/*!40000 ALTER TABLE `cp_event_loggers` DISABLE KEYS */;
INSERT INTO `cp_event_loggers` VALUES (1,1,1,NULL,NULL,NULL,'limited'),(2,10,1,NULL,NULL,NULL,'limited'),(3,1,2,NULL,NULL,NULL,'limited');
/*!40000 ALTER TABLE `cp_event_loggers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cp_event_teams`
--

DROP TABLE IF EXISTS `cp_event_teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cp_event_teams` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_event` int(11) DEFAULT NULL,
  `id_team` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8 COMMENT='These are the options available per event - includes additional teams that admin has added per event (the instance is justified in the template table) - event_teams are the options that users can select during registration';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cp_event_teams`
--

LOCK TABLES `cp_event_teams` WRITE;
/*!40000 ALTER TABLE `cp_event_teams` DISABLE KEYS */;
INSERT INTO `cp_event_teams` VALUES (1,0,1),(2,0,2),(3,0,3),(4,0,4),(5,0,5),(6,0,6),(7,0,7),(8,0,8),(9,0,9),(10,0,10),(11,0,11),(12,0,12),(13,0,13),(14,0,14),(15,0,15),(16,0,16),(17,0,17),(18,0,18),(19,0,19),(20,0,20),(21,0,21),(22,0,22),(23,1,23),(24,0,24),(25,2,23),(26,0,25);
/*!40000 ALTER TABLE `cp_event_teams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cp_events`
--

DROP TABLE IF EXISTS `cp_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cp_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_company` int(11) DEFAULT NULL,
  `event_title` varchar(256) DEFAULT NULL,
  `event_start_date` date DEFAULT NULL,
  `event_finish_date` date DEFAULT NULL,
  `event_timezone` varchar(128) DEFAULT NULL,
  `event_billing_type` int(1) DEFAULT '0',
  `event_billing_processed` int(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cp_events`
--

LOCK TABLES `cp_events` WRITE;
/*!40000 ALTER TABLE `cp_events` DISABLE KEYS */;
INSERT INTO `cp_events` VALUES (1,1,'Vivid Sydney 2020','2020-05-22','2020-05-22','Sydney/Australia',0,0),(2,1,'Australia Day 2021','2020-05-22','2020-05-22','Sydney/Australia',0,0);
/*!40000 ALTER TABLE `cp_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cp_incident_log`
--

DROP TABLE IF EXISTS `cp_incident_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cp_incident_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `log_increment_id` int(11) DEFAULT NULL,
  `id_tab` int(11) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  `log_title` varchar(128) DEFAULT NULL,
  `id_instance` int(11) DEFAULT NULL,
  `id_event` int(11) DEFAULT NULL,
  `status` int(5) DEFAULT '1' COMMENT 'NOT in use - need method to manage duplicates ',
  `log_created_time` timestamp NULL DEFAULT NULL COMMENT 'REMOVE - using ''_instance_share''',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=123 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cp_incident_log`
--

LOCK TABLES `cp_incident_log` WRITE;
/*!40000 ALTER TABLE `cp_incident_log` DISABLE KEYS */;
INSERT INTO `cp_incident_log` VALUES (1,1,0,1,'Signage Hazard - Millsons Point',1,1,1,'2020-04-13 14:00:00'),(2,2,3,1,'-',1,1,1,'2020-04-13 14:00:00'),(12,NULL,2,10,'Bin Fire - Room 1',2,1,1,'2020-04-15 18:13:17'),(15,NULL,1,1,'301 - Armed Persons - ECQ',3,1,1,'2020-04-15 23:40:56'),(16,NULL,5,1,'Intoxicated Persons - WCQ Info',3,1,1,'2020-04-15 23:59:06'),(17,NULL,5,1,'Intoxicated Persons - WCQ',3,1,1,'2020-04-15 23:59:55'),(18,NULL,1,10,'101 - Homicide - Location',2,1,1,'2020-04-16 15:46:51'),(19,NULL,1,10,'112 - Attempted Rape - Loc',2,1,1,'2020-04-16 15:56:02'),(20,NULL,1,10,'',2,1,1,'2020-04-16 15:58:23'),(21,NULL,1,10,'123 - Stealing - Loc',2,1,1,'2020-04-16 15:59:41'),(22,NULL,1,10,'121 - Armed Hold-Up - Loc',2,1,1,'2020-04-16 16:00:57'),(23,NULL,1,10,'101 - Homicide - Loc',2,1,1,'2020-04-16 16:03:30'),(24,NULL,1,10,'101 - Homicide - loc',2,1,1,'2020-04-16 16:05:50'),(25,NULL,1,10,'113 - Indecient Assault - lov',2,1,1,'2020-04-16 16:07:17'),(26,NULL,1,10,'113 - Indecient Assault - lov',2,1,1,'2020-04-16 16:11:43'),(27,NULL,1,10,'131 - Breaker at Premises - loc',2,1,1,'2020-04-16 16:13:25'),(28,NULL,1,10,'113 - Indecient Assault - loc',2,1,1,'2020-04-16 16:16:08'),(29,NULL,1,10,'141 - Poweler - loc',2,1,1,'2020-04-16 16:17:08'),(30,NULL,1,10,'114 - Wilful Exposure - lov',2,1,1,'2020-04-16 16:18:27'),(31,NULL,1,10,'101 - Homicide - loc',2,1,1,'2020-04-16 16:19:34'),(32,NULL,1,10,'141 - Poweler - loc',2,1,1,'2020-04-16 16:31:25'),(33,NULL,1,10,'141 - Poweler - loc',2,1,1,'2020-04-16 16:33:38'),(34,NULL,1,10,'104 - Abduction - loc',2,1,1,'2020-04-16 16:53:17'),(35,NULL,1,10,'101 - Homicide - Loc',2,1,1,'2020-04-16 16:54:29'),(36,NULL,1,10,'101 - Homicide - loc',2,1,1,'2020-04-16 16:58:36'),(37,NULL,1,10,'101 - Homicide - Loc',2,1,1,'2020-04-16 17:02:22'),(38,NULL,1,10,'101 - Homicide - loc',2,1,1,'2020-04-16 17:05:17'),(39,NULL,1,10,'101 - Homicide - loc',2,1,1,'2020-04-16 17:06:49'),(40,NULL,1,10,'2121 - 12312321',2,1,1,'2020-04-16 17:09:14'),(41,NULL,1,10,'2121 - 12312321',2,1,1,'2020-04-16 17:09:14'),(42,NULL,1,10,'wewqe - wqeqwew',2,1,1,'2020-04-16 17:11:17'),(43,NULL,1,10,'wewqe - wqeqwew',2,1,1,'2020-04-16 17:11:18'),(44,NULL,1,10,'wwew - wewqewq',2,1,1,'2020-04-16 17:12:00'),(45,NULL,1,10,'232321 - 2321321',2,1,1,'2020-04-16 17:15:25'),(46,NULL,1,10,'qwwqe - ewqeq',2,1,1,'2020-04-16 17:16:10'),(47,NULL,1,10,'1212323 - 3213232',2,1,1,'2020-04-16 17:18:47'),(48,NULL,1,10,'123 - Stealing - 123',2,1,1,'2020-04-16 17:20:22'),(49,NULL,1,10,'123 - Stealing - 123',2,1,1,'2020-04-16 17:24:19'),(50,NULL,1,10,'123 - Stealing - 1213',2,1,1,'2020-04-16 17:33:10'),(51,NULL,1,10,'123 - Stealing - 123',2,1,1,'2020-04-16 17:33:29'),(52,NULL,2,10,'123 - 123',2,1,1,'2020-04-16 17:34:21'),(53,NULL,3,10,'123 - 123',2,1,1,'2020-04-16 17:37:18'),(54,NULL,3,10,'123 - 123',2,1,1,'2020-04-16 17:40:30'),(55,NULL,3,10,'123 - 123',2,1,1,'2020-04-16 17:46:17'),(56,NULL,3,10,'123 - 123',2,1,1,'2020-04-16 17:48:10'),(57,NULL,3,10,'123 - 123',2,1,1,'2020-04-16 17:56:02'),(58,NULL,3,10,'123 - 123',2,1,1,'2020-04-16 17:57:07'),(59,NULL,3,10,'Abdominal / Stomach Pain / Problems - loc',2,1,1,'2020-04-16 18:59:02'),(60,NULL,3,10,'123 - 123',2,1,1,'2020-04-16 18:59:20'),(61,NULL,3,10,'123 - 123',2,1,1,'2020-04-16 18:59:57'),(62,NULL,3,10,'123 - 123',2,1,1,'2020-04-16 19:00:23'),(63,NULL,3,10,'1 - 2',2,1,1,'2020-04-16 19:00:36'),(64,NULL,3,10,'1 - 2',2,1,1,'2020-04-16 19:04:01'),(65,NULL,3,10,'2 - 3',2,1,1,'2020-04-16 19:04:10'),(66,NULL,3,10,'4 - 5',2,1,1,'2020-04-16 19:04:21'),(67,NULL,3,10,'1 - 2',2,1,1,'2020-04-16 19:07:22'),(68,NULL,3,10,'1 - 2',2,1,1,'2020-04-16 19:07:34'),(69,NULL,3,10,'1 - 2',2,1,1,'2020-04-16 19:07:54'),(70,NULL,3,10,'2 - 3',2,1,1,'2020-04-16 19:20:41'),(71,NULL,1,10,'1 - 2',2,1,1,'2020-04-16 19:21:20'),(72,NULL,0,10,'2 - 3',2,1,1,'2020-04-16 19:24:57'),(73,NULL,3,10,'Abdominal / Stomach Pain / Problems - Location 5',2,1,1,'2020-04-16 19:25:55'),(74,NULL,3,1,'Stab / Gunshot / Penetrating Trauma - ECQ-W',3,1,1,'2020-04-16 23:35:19'),(75,NULL,1,1,'102 - Serious Assault - WCQ Info',3,1,1,'2020-04-16 23:48:23'),(76,NULL,4,1,'Missing Child - WCQ Info',3,1,1,'2020-04-16 23:53:42'),(77,NULL,5,1,'Assault - ECQ',3,1,1,'2020-04-17 00:12:36'),(78,NULL,3,10,'1 - 2',2,1,1,'2020-04-17 08:24:36'),(79,NULL,3,10,'1 - 2',2,1,1,'2020-04-17 08:25:03'),(80,NULL,3,10,'1 - 2',2,1,1,'2020-04-17 08:33:42'),(81,NULL,3,10,'3 - 4',2,1,1,'2020-04-17 08:33:58'),(82,NULL,3,10,'1 - 2',2,1,1,'2020-04-17 08:34:47'),(83,NULL,3,10,'1 - 2',2,1,1,'2020-04-17 08:34:57'),(84,NULL,3,10,'1 - 2',2,1,1,'2020-04-17 08:35:07'),(85,NULL,3,10,'1 - 2',2,1,1,'2020-04-17 08:44:05'),(86,NULL,3,10,'1 - 2',2,1,1,'2020-04-17 08:44:32'),(87,NULL,3,10,'1 - 2',2,1,1,'2020-04-17 08:44:51'),(88,NULL,3,10,'1 - 2',2,1,1,'2020-04-17 08:45:02'),(89,NULL,3,10,'1 - 2',2,1,1,'2020-04-17 08:49:49'),(90,NULL,3,10,'1 - 2',2,1,1,'2020-04-17 08:49:58'),(91,NULL,3,10,'1 - 2',2,1,1,'2020-04-17 08:50:08'),(92,NULL,3,10,'1 - 2',2,1,1,'2020-04-17 08:50:16'),(93,NULL,4,10,'1 - 2',2,1,1,'2020-04-17 09:03:05'),(94,NULL,1,10,NULL,2,1,1,NULL),(95,NULL,1,10,NULL,2,1,1,NULL),(96,NULL,1,10,NULL,2,1,1,NULL),(97,NULL,1,10,NULL,2,1,1,NULL),(98,NULL,1,10,NULL,2,1,1,NULL),(99,88,1,10,'1 - 2',2,1,1,'2020-04-17 12:32:11'),(100,89,1,10,'1 - 2',2,1,1,'2020-04-17 12:32:25'),(101,90,1,10,'Custom - loc',2,1,1,'2020-04-17 12:44:31'),(102,91,1,10,'111 - 111',2,1,1,'2020-04-17 12:51:20'),(103,92,1,10,'101 - Homicide - loc',2,1,1,'2020-04-17 12:51:50'),(104,93,1,10,'113 - Indecient Assault - loc',2,1,1,'2020-04-17 12:52:01'),(105,94,1,10,'Custom option here - Loc',2,1,1,'2020-04-17 12:58:11'),(106,95,1,10,'Another custom text - Loc',2,1,1,'2020-04-17 12:59:25'),(107,96,1,10,'121 - Armed Hold-Up - loc',2,1,1,'2020-04-17 13:00:21'),(108,97,4,1,'Missing Child - ECQ-N',2,1,1,'2020-04-17 13:03:11'),(109,1,2,1,'Building Alarm - loc1',6,2,1,'2020-04-17 13:07:11'),(110,2,1,1,'403 - Fire - Grass - test',6,2,1,'2020-04-17 13:08:08'),(111,3,1,1,'Manual Entry - q',6,2,1,'2020-04-17 13:16:20'),(112,4,3,1,'Broken Bone - test',6,2,1,'2020-04-17 13:29:29'),(113,5,3,1,'Broken Bone - test',6,2,1,'2020-04-17 13:29:30'),(114,6,3,1,'Broken Bone  - 4',6,2,1,'2020-04-17 13:29:38'),(115,7,3,1,'Broken Bone  - 4',6,2,1,'2020-04-17 13:29:39'),(116,8,2,1,'Elevator / Escalator Rescue  - 4',6,2,1,'2020-04-17 13:30:26'),(117,9,2,1,'Elevator / Escalator Rescue  - 4',6,2,1,'2020-04-17 13:30:27'),(118,10,14,1,'test - test',6,2,1,'2020-04-17 13:41:37'),(119,11,14,1,'test - test',6,2,1,'2020-04-17 13:42:07'),(120,12,3,1,NULL,6,2,1,'2020-04-19 01:33:34'),(121,13,3,1,'test - q',6,2,1,'2020-04-19 01:34:04'),(122,14,3,1,NULL,6,2,1,'2020-04-19 01:35:09');
/*!40000 ALTER TABLE `cp_incident_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cp_incident_log_collaboration_users`
--

DROP TABLE IF EXISTS `cp_incident_log_collaboration_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cp_incident_log_collaboration_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_log` int(11) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  `id_user_added` int(11) DEFAULT NULL,
  `collaborator_added_time` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cp_incident_log_collaboration_users`
--

LOCK TABLES `cp_incident_log_collaboration_users` WRITE;
/*!40000 ALTER TABLE `cp_incident_log_collaboration_users` DISABLE KEYS */;
INSERT INTO `cp_incident_log_collaboration_users` VALUES (1,1,10,1,'2020-04-13 14:00:00'),(2,1,1,10,'2020-04-13 14:00:00');
/*!40000 ALTER TABLE `cp_incident_log_collaboration_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cp_incident_log_dispatch_location`
--

DROP TABLE IF EXISTS `cp_incident_log_dispatch_location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cp_incident_log_dispatch_location` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_log` int(11) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  `log_dispatch_address` varchar(256) DEFAULT NULL,
  `log_latitude` varchar(64) DEFAULT NULL,
  `log_longitude` varchar(64) DEFAULT NULL,
  `location_created_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cp_incident_log_dispatch_location`
--

LOCK TABLES `cp_incident_log_dispatch_location` WRITE;
/*!40000 ALTER TABLE `cp_incident_log_dispatch_location` DISABLE KEYS */;
INSERT INTO `cp_incident_log_dispatch_location` VALUES (1,1,1,'240 Pitt Street, Sydney Australia 2000','151.1284725','-33.97087143','2020-04-13 14:00:00'),(2,1,1,'241 Pitt Street, Sydney Australia 2000','151.1284725','-33.97087143','2020-04-13 14:00:00'),(3,10,10,'Nowhere',NULL,NULL,NULL),(4,11,10,'There',NULL,NULL,'2020-04-15 18:08:37'),(5,12,10,'Somewhere',NULL,NULL,'2020-04-15 18:13:17'),(6,15,1,'Circular Quay',NULL,NULL,'2020-04-15 23:40:56'),(7,16,1,'',NULL,NULL,'2020-04-15 23:59:06'),(8,17,1,'',NULL,NULL,'2020-04-15 23:59:55'),(9,18,10,'',NULL,NULL,'2020-04-16 15:46:51'),(10,21,10,'',NULL,NULL,'2020-04-16 15:59:41'),(11,73,10,'2233-4455',NULL,NULL,'2020-04-16 19:25:55'),(12,75,1,'WCQ',NULL,NULL,'2020-04-16 23:48:23');
/*!40000 ALTER TABLE `cp_incident_log_dispatch_location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cp_incident_log_images`
--

DROP TABLE IF EXISTS `cp_incident_log_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cp_incident_log_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_log` int(11) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  `log_file_path` varchar(256) DEFAULT NULL,
  `attachment_upload_time` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cp_incident_log_images`
--

LOCK TABLES `cp_incident_log_images` WRITE;
/*!40000 ALTER TABLE `cp_incident_log_images` DISABLE KEYS */;
INSERT INTO `cp_incident_log_images` VALUES (1,1,1,'file_name','2020-04-13 14:00:00');
/*!40000 ALTER TABLE `cp_incident_log_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cp_incident_log_instance_share`
--

DROP TABLE IF EXISTS `cp_incident_log_instance_share`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cp_incident_log_instance_share` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_log` int(11) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  `id_instance` int(11) DEFAULT NULL,
  `log_status` int(11) DEFAULT '1' COMMENT '1=pending, 2=duplicate, 3=completed',
  `log_share_time` timestamp NULL DEFAULT NULL,
  `log_completed_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cp_incident_log_instance_share`
--

LOCK TABLES `cp_incident_log_instance_share` WRITE;
/*!40000 ALTER TABLE `cp_incident_log_instance_share` DISABLE KEYS */;
INSERT INTO `cp_incident_log_instance_share` VALUES (1,1,1,4,1,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(2,1,1,2,1,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(3,2,10,0,1,'0000-00-00 00:00:00','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `cp_incident_log_instance_share` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cp_incident_log_location_record`
--

DROP TABLE IF EXISTS `cp_incident_log_location_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cp_incident_log_location_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_log` int(11) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  `location_details` varchar(256) DEFAULT NULL,
  `log_entry_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cp_incident_log_location_record`
--

LOCK TABLES `cp_incident_log_location_record` WRITE;
/*!40000 ALTER TABLE `cp_incident_log_location_record` DISABLE KEYS */;
INSERT INTO `cp_incident_log_location_record` VALUES (1,1,1,'Milsons Point Front Gate','2020-04-13 14:00:00'),(2,2,1,'WCQ - A44','2020-04-13 14:00:00'),(6,12,10,'Room 1','2020-04-15 18:13:17'),(9,15,1,'ECQ','2020-04-15 23:40:56'),(10,16,1,'WCQ Info','2020-04-15 23:59:06'),(11,17,1,'WCQ','2020-04-15 23:59:55'),(12,18,10,'Location','2020-04-16 15:46:51'),(13,19,10,'Loc','2020-04-16 15:56:02'),(14,21,10,'Loc','2020-04-16 15:59:41'),(15,22,10,'Loc','2020-04-16 16:00:57'),(16,23,10,'Loc','2020-04-16 16:03:30'),(17,24,10,'loc','2020-04-16 16:05:50'),(18,25,10,'lov','2020-04-16 16:07:17'),(19,26,10,'lov','2020-04-16 16:11:43'),(20,27,10,'loc','2020-04-16 16:13:25'),(21,28,10,'loc','2020-04-16 16:16:08'),(22,29,10,'loc','2020-04-16 16:17:08'),(23,30,10,'lov','2020-04-16 16:18:27'),(24,31,10,'loc','2020-04-16 16:19:34'),(25,32,10,'loc','2020-04-16 16:31:25'),(26,33,10,'loc','2020-04-16 16:33:38'),(27,34,10,'loc','2020-04-16 16:53:17'),(28,35,10,'Loc','2020-04-16 16:54:29'),(29,36,10,'loc','2020-04-16 16:58:36'),(30,37,10,'Loc','2020-04-16 17:02:22'),(31,38,10,'loc','2020-04-16 17:05:17'),(32,39,10,'loc','2020-04-16 17:06:49'),(33,40,10,'12312321','2020-04-16 17:09:14'),(34,41,10,'12312321','2020-04-16 17:09:14'),(35,42,10,'wqeqwew','2020-04-16 17:11:17'),(36,43,10,'wqeqwew','2020-04-16 17:11:18'),(37,44,10,'wewqewq','2020-04-16 17:12:00'),(38,45,10,'2321321','2020-04-16 17:15:25'),(39,46,10,'ewqeq','2020-04-16 17:16:10'),(40,47,10,'3213232','2020-04-16 17:18:47'),(41,48,10,'123','2020-04-16 17:20:22'),(42,49,10,'123','2020-04-16 17:24:19'),(43,50,10,'1213','2020-04-16 17:33:10'),(44,51,10,'123','2020-04-16 17:33:29'),(45,52,10,'123','2020-04-16 17:34:21'),(46,53,10,'123','2020-04-16 17:37:18'),(47,54,10,'123','2020-04-16 17:40:30'),(48,55,10,'123','2020-04-16 17:46:17'),(49,56,10,'123','2020-04-16 17:48:10'),(50,57,10,'123','2020-04-16 17:56:02'),(51,58,10,'123','2020-04-16 17:57:07'),(52,59,10,'loc','2020-04-16 18:59:02'),(53,60,10,'123','2020-04-16 18:59:20'),(54,61,10,'123','2020-04-16 18:59:57'),(55,62,10,'123','2020-04-16 19:00:23'),(56,63,10,'2','2020-04-16 19:00:36'),(57,64,10,'2','2020-04-16 19:04:01'),(58,65,10,'3','2020-04-16 19:04:10'),(59,66,10,'5','2020-04-16 19:04:21'),(60,67,10,'2','2020-04-16 19:07:22'),(61,68,10,'2','2020-04-16 19:07:34'),(62,69,10,'2','2020-04-16 19:07:54'),(63,70,10,'3','2020-04-16 19:20:41'),(64,71,10,'2','2020-04-16 19:21:20'),(65,72,10,'3','2020-04-16 19:24:57'),(66,73,10,'Location 5','2020-04-16 19:25:54'),(67,74,1,'ECQ-W','2020-04-16 23:35:19'),(68,75,1,'WCQ Info','2020-04-16 23:48:23'),(69,76,1,'WCQ Info','2020-04-16 23:53:42'),(70,77,1,'ECQ','2020-04-17 00:12:36'),(71,78,10,'2','2020-04-17 08:24:36'),(72,79,10,'2','2020-04-17 08:25:03'),(73,80,10,'2','2020-04-17 08:33:42'),(74,81,10,'4','2020-04-17 08:33:58'),(75,82,10,'2','2020-04-17 08:34:47'),(76,83,10,'2','2020-04-17 08:34:57'),(77,84,10,'2','2020-04-17 08:35:07'),(78,85,10,'2','2020-04-17 08:44:05'),(79,86,10,'2','2020-04-17 08:44:32'),(80,87,10,'2','2020-04-17 08:44:51'),(81,88,10,'2','2020-04-17 08:45:02'),(82,89,10,'2','2020-04-17 08:49:49'),(83,90,10,'2','2020-04-17 08:49:58'),(84,91,10,'2','2020-04-17 08:50:08'),(85,92,10,'2','2020-04-17 08:50:16'),(86,93,10,'2','2020-04-17 09:03:05'),(87,99,10,'2','2020-04-17 12:32:11'),(88,100,10,'2','2020-04-17 12:32:25'),(89,101,10,'loc','2020-04-17 12:44:31'),(90,102,10,'111','2020-04-17 12:51:20'),(91,103,10,'loc','2020-04-17 12:51:50'),(92,104,10,'loc','2020-04-17 12:52:01'),(93,105,10,'Loc','2020-04-17 12:58:11'),(94,106,10,'Loc','2020-04-17 12:59:25'),(95,107,10,'loc','2020-04-17 13:00:21'),(96,108,1,'ECQ-N','2020-04-17 13:03:11'),(97,109,1,'loc1','2020-04-17 13:07:11'),(98,110,1,'test','2020-04-17 13:08:08'),(99,111,1,'q','2020-04-17 13:16:21'),(100,112,1,'test','2020-04-17 13:29:29'),(101,113,1,'test','2020-04-17 13:29:30'),(102,114,1,'4','2020-04-17 13:29:38'),(103,115,1,'4','2020-04-17 13:29:39'),(104,116,1,'4','2020-04-17 13:30:26'),(105,117,1,'4','2020-04-17 13:30:27'),(106,118,1,'test','2020-04-17 13:41:37'),(107,119,1,'test','2020-04-17 13:42:07'),(108,121,1,'q','2020-04-19 01:34:04');
/*!40000 ALTER TABLE `cp_incident_log_location_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cp_incident_log_particulars_record`
--

DROP TABLE IF EXISTS `cp_incident_log_particulars_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cp_incident_log_particulars_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_log` int(11) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  `id_field` int(11) DEFAULT NULL,
  `id_field_option` varchar(128) DEFAULT NULL,
  `field_response` varchar(256) DEFAULT NULL,
  `log_entry_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=156 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cp_incident_log_particulars_record`
--

LOCK TABLES `cp_incident_log_particulars_record` WRITE;
/*!40000 ALTER TABLE `cp_incident_log_particulars_record` DISABLE KEYS */;
INSERT INTO `cp_incident_log_particulars_record` VALUES (104,59,10,13,'','Exact: 23','2020-04-16 18:59:02'),(105,60,10,13,'','Estimate','2020-04-16 18:59:20'),(106,61,10,13,'','Range','2020-04-16 18:59:57'),(107,62,10,13,'','Range: 3 - 9','2020-04-16 19:00:23'),(108,63,10,13,'','Exact','2020-04-16 19:00:36'),(109,64,10,13,'','Exact: 99','2020-04-16 19:04:01'),(110,65,10,13,'','Exact: 88','2020-04-16 19:04:10'),(111,66,10,13,'','Range: 2 - 99','2020-04-16 19:04:21'),(112,67,10,13,'','Range: 3 - 4','2020-04-16 19:07:22'),(113,68,10,13,'','Exact: 44','2020-04-16 19:07:34'),(114,69,10,13,'','Estimate: 88','2020-04-16 19:07:54'),(115,70,10,13,'','Range: 4 - 99','2020-04-16 19:20:41'),(116,72,10,0,'','1','2020-04-16 19:24:57'),(117,73,10,12,'','Tirex','2020-04-16 19:25:54'),(118,73,10,13,'','Range: 1 - 3','2020-04-16 19:25:54'),(119,73,10,14,'','Non-Binary','2020-04-16 19:25:54'),(120,73,10,15,'','Yes','2020-04-16 19:25:54'),(121,73,10,16,'','Yes','2020-04-16 19:25:54'),(122,73,10,17,'','No','2020-04-16 19:25:54'),(123,73,10,18,'','Police','2020-04-16 19:25:54'),(124,73,10,18,'','Fire','2020-04-16 19:25:54'),(125,73,10,19,'','No','2020-04-16 19:25:54'),(126,73,10,20,'','Many','2020-04-16 19:25:54'),(127,73,10,1,'','Fear','2020-04-16 19:25:54'),(128,74,1,13,'','Range','2020-04-16 23:35:19'),(129,75,1,1,'','Man with knife','2020-04-16 23:48:23'),(130,75,1,38,'47','','2020-04-16 23:48:23'),(131,75,1,3,'16','','2020-04-16 23:48:23'),(132,75,1,4,'','Ambulance','2020-04-16 23:48:23'),(133,76,1,22,'','John','2020-04-16 23:53:42'),(134,76,1,23,'','Range: 5 - 7','2020-04-16 23:53:42'),(135,76,1,24,'','Male','2020-04-16 23:53:42'),(136,76,1,25,'','Black over green','2020-04-16 23:53:42'),(137,76,1,26,'38','','2020-04-16 23:53:42'),(138,76,1,31,'','Unknown','2020-04-16 23:53:42'),(139,78,10,13,'','Exact: 88','2020-04-17 08:24:36'),(140,79,10,13,'','Range: 2 - 5','2020-04-17 08:25:03'),(141,80,10,13,'','Infant: 4 months','2020-04-17 08:33:42'),(142,81,10,13,'','Range: 3 - 6yo','2020-04-17 08:33:58'),(143,82,10,13,'','Estimate: 99yo','2020-04-17 08:34:47'),(144,83,10,13,'','Exact: 88yo','2020-04-17 08:34:57'),(145,84,10,13,'','Range: 1 - 99yo','2020-04-17 08:35:07'),(146,85,10,13,'','99yo (Exact)','2020-04-17 08:44:05'),(147,86,10,13,'','Approx. 70yo (Estimate)','2020-04-17 08:44:32'),(148,87,10,13,'','Between 2 - 8yo (Range)','2020-04-17 08:44:51'),(149,88,10,13,'','Infant: 8 months (Infant)','2020-04-17 08:45:02'),(150,89,10,13,'','99yo (Exact)','2020-04-17 08:49:49'),(151,90,10,13,'','Approx. 50yo','2020-04-17 08:49:58'),(152,91,10,13,'','Between 1 - 5yo','2020-04-17 08:50:08'),(153,92,10,13,'','Infant 9 months','2020-04-17 08:50:16'),(154,93,10,39,'','Between 1 - 4yo','2020-04-17 09:03:05'),(155,93,10,23,'','Approx. 88yo','2020-04-17 09:03:05');
/*!40000 ALTER TABLE `cp_incident_log_particulars_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cp_incident_log_remarks`
--

DROP TABLE IF EXISTS `cp_incident_log_remarks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cp_incident_log_remarks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_log` int(11) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  `log_remark` varchar(256) DEFAULT NULL,
  `remark_created_time` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cp_incident_log_remarks`
--

LOCK TABLES `cp_incident_log_remarks` WRITE;
/*!40000 ALTER TABLE `cp_incident_log_remarks` DISABLE KEYS */;
INSERT INTO `cp_incident_log_remarks` VALUES (1,1,1,'This is a comment made by user_id 1','2020-04-13 14:00:00');
/*!40000 ALTER TABLE `cp_incident_log_remarks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cp_incident_log_remarks_highlights`
--

DROP TABLE IF EXISTS `cp_incident_log_remarks_highlights`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cp_incident_log_remarks_highlights` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_remark` int(11) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  `remark_highlight_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cp_incident_log_remarks_highlights`
--

LOCK TABLES `cp_incident_log_remarks_highlights` WRITE;
/*!40000 ALTER TABLE `cp_incident_log_remarks_highlights` DISABLE KEYS */;
INSERT INTO `cp_incident_log_remarks_highlights` VALUES (1,1,10,'2020-04-13 14:00:00');
/*!40000 ALTER TABLE `cp_incident_log_remarks_highlights` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cp_incident_log_type_record`
--

DROP TABLE IF EXISTS `cp_incident_log_type_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cp_incident_log_type_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_log` int(11) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  `id_type_option` int(11) DEFAULT NULL,
  `type_response` varchar(256) DEFAULT NULL,
  `log_entry_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cp_incident_log_type_record`
--

LOCK TABLES `cp_incident_log_type_record` WRITE;
/*!40000 ALTER TABLE `cp_incident_log_type_record` DISABLE KEYS */;
INSERT INTO `cp_incident_log_type_record` VALUES (1,1,1,NULL,'This was a manual entry so no match for type','0000-00-00 00:00:00'),(2,2,1,212,NULL,'0000-00-00 00:00:00'),(63,70,10,NULL,'2','2020-04-16 19:20:41'),(64,71,10,NULL,'1','2020-04-16 19:21:20'),(65,72,10,NULL,'2','2020-04-16 19:24:57'),(66,73,10,NULL,'Abdominal / Stomach Pain / Problems','2020-04-16 19:25:54'),(67,74,1,NULL,'Stab / Gunshot / Penetrating Trauma','2020-04-16 23:35:19'),(68,75,1,NULL,'102 - Serious Assault','2020-04-16 23:48:23'),(69,76,1,NULL,'Missing Child','2020-04-16 23:53:42'),(70,77,1,NULL,'Assault','2020-04-17 00:12:36'),(71,78,10,NULL,'1','2020-04-17 08:24:36'),(72,79,10,NULL,'1','2020-04-17 08:25:03'),(73,80,10,NULL,'1','2020-04-17 08:33:42'),(74,81,10,NULL,'3','2020-04-17 08:33:58'),(75,82,10,NULL,'1','2020-04-17 08:34:47'),(76,83,10,NULL,'1','2020-04-17 08:34:57'),(77,84,10,NULL,'1','2020-04-17 08:35:07'),(78,85,10,NULL,'1','2020-04-17 08:44:05'),(79,86,10,NULL,'1','2020-04-17 08:44:32'),(80,87,10,NULL,'1','2020-04-17 08:44:51'),(81,88,10,NULL,'1','2020-04-17 08:45:02'),(82,89,10,NULL,'1','2020-04-17 08:49:49'),(83,90,10,NULL,'1','2020-04-17 08:49:58'),(84,91,10,NULL,'1','2020-04-17 08:50:08'),(85,92,10,NULL,'1','2020-04-17 08:50:16'),(86,93,10,NULL,'1','2020-04-17 09:03:05'),(87,99,10,NULL,'1','2020-04-17 12:32:11'),(88,100,10,NULL,'1','2020-04-17 12:32:25'),(89,101,10,NULL,'Custom','2020-04-17 12:44:31'),(90,102,10,NULL,'111','2020-04-17 12:51:20'),(91,103,10,NULL,'101 - Homicide','2020-04-17 12:51:50'),(92,104,10,NULL,'113 - Indecient Assault','2020-04-17 12:52:01'),(93,105,10,0,'Custom option here','2020-04-17 12:58:11'),(94,106,10,NULL,'Another custom text','2020-04-17 12:59:25'),(95,107,10,13,'','2020-04-17 13:00:21'),(96,108,1,336,'','2020-04-17 13:03:11'),(97,109,1,195,'','2020-04-17 13:07:11'),(98,110,1,65,'','2020-04-17 13:08:08'),(99,111,1,NULL,'Manual Entry','2020-04-17 13:16:21'),(100,112,1,251,'','2020-04-17 13:29:29'),(101,113,1,251,'','2020-04-17 13:29:30'),(102,114,1,251,'','2020-04-17 13:29:38'),(103,115,1,251,'','2020-04-17 13:29:39'),(104,116,1,176,'','2020-04-17 13:30:26'),(105,117,1,176,'','2020-04-17 13:30:27'),(106,118,1,NULL,'test','2020-04-17 13:41:37'),(107,119,1,NULL,'test','2020-04-17 13:42:07'),(108,121,1,NULL,'test','2020-04-19 01:34:04');
/*!40000 ALTER TABLE `cp_incident_log_type_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cp_instance_teams`
--

DROP TABLE IF EXISTS `cp_instance_teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cp_instance_teams` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `team_title` varchar(128) DEFAULT NULL,
  `id_instance` int(11) DEFAULT NULL,
  `id_organisation` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COMMENT='This is more of a template (central table - which lists all teams). It includes the default teams for each room (instance) for system-wide use. This table should be referenced when admin is creating a new instance and is used when admin wants to add their own teams in addition to default (ie. ‘Staff & Volunteer Coordinators’) - ie. overriding default options. Custom entries remains remembered for that organisation to use in the future.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cp_instance_teams`
--

LOCK TABLES `cp_instance_teams` WRITE;
/*!40000 ALTER TABLE `cp_instance_teams` DISABLE KEYS */;
INSERT INTO `cp_instance_teams` VALUES (1,'N/A',0,0),(2,'Police Media',1,0),(3,'Dispatch',1,0),(4,'Forward Command',1,0),(5,'Police Station',1,0),(6,'Highway Patrol',1,0),(7,'Marine',1,0),(8,'Police',2,0),(9,'Fire + Rescue',2,0),(10,'Ambulance',2,0),(11,'Taxi Council',2,0),(12,'Security',2,0),(13,'Traffic Management Centre',3,0),(14,'Volunteer Management',3,0),(15,'Event Control Manager',3,0),(16,'Security',3,0),(17,'Medical / First Aid',3,0),(18,'Site Management',3,0),(19,'Media / Social Media',2,0),(20,'Cleaning Services',3,0),(21,'Production',3,0),(22,'Show Control',3,0),(23,'Staff & Volunteer Coordinators',6,1),(24,'Event Owner',2,0),(25,'State Emergency Services (SES)',2,0);
/*!40000 ALTER TABLE `cp_instance_teams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cp_instances`
--

DROP TABLE IF EXISTS `cp_instances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cp_instances` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `instance_title` varchar(256) DEFAULT NULL,
  `instance_shortname` varchar(8) DEFAULT NULL,
  `instance_active` int(1) DEFAULT '0',
  `id_company` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cp_instances`
--

LOCK TABLES `cp_instances` WRITE;
/*!40000 ALTER TABLE `cp_instances` DISABLE KEYS */;
INSERT INTO `cp_instances` VALUES (1,'Police Operation Centre','POC',1,0),(2,'Government Coordination Centre','GCC',1,0),(3,'Event Control Centre','ECC',1,0),(4,'Security Operations Centre','SOC',1,0),(5,'Event Operations Centre','EOC',1,0),(6,'Volunteer Operations Centre','VOC',1,0),(7,'Traffic Management Centre','TMC',1,0),(8,'Joint Operations Centre','JOC',1,0),(9,'Ambulance Operation Centre','AOC',1,0),(10,'Custom Instance','TEST',1,1),(11,'Sandbox Operation','SAND',2,0),(12,'Administrator','ADMIN',2,0);
/*!40000 ALTER TABLE `cp_instances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cp_logger_instances`
--

DROP TABLE IF EXISTS `cp_logger_instances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cp_logger_instances` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_logger` int(11) DEFAULT NULL,
  `id_instance` int(11) DEFAULT NULL,
  `id_event` int(11) DEFAULT NULL,
  `logger_active` int(1) DEFAULT '0',
  `billing_status` int(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cp_logger_instances`
--

LOCK TABLES `cp_logger_instances` WRITE;
/*!40000 ALTER TABLE `cp_logger_instances` DISABLE KEYS */;
INSERT INTO `cp_logger_instances` VALUES (1,1,3,1,1,0),(2,10,1,1,1,0),(3,10,2,1,1,0),(4,1,2,1,1,0),(8,1,6,2,1,0),(9,10,6,2,1,0);
/*!40000 ALTER TABLE `cp_logger_instances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cp_logger_permissions`
--

DROP TABLE IF EXISTS `cp_logger_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cp_logger_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_logger` int(11) DEFAULT NULL,
  `id_event` int(11) DEFAULT NULL,
  `id_app` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cp_logger_permissions`
--

LOCK TABLES `cp_logger_permissions` WRITE;
/*!40000 ALTER TABLE `cp_logger_permissions` DISABLE KEYS */;
INSERT INTO `cp_logger_permissions` VALUES (1,1,1,1),(2,1,1,2),(3,1,1,3),(4,1,1,4);
/*!40000 ALTER TABLE `cp_logger_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cp_logging_toolbar_tabs`
--

DROP TABLE IF EXISTS `cp_logging_toolbar_tabs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cp_logging_toolbar_tabs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `log_tab_title` varchar(128) DEFAULT NULL,
  `tab_setting` varchar(64) DEFAULT NULL,
  `tab_icon` varchar(64) DEFAULT NULL,
  `tab_status` int(1) DEFAULT NULL,
  `id_organisation` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cp_logging_toolbar_tabs`
--

LOCK TABLES `cp_logging_toolbar_tabs` WRITE;
/*!40000 ALTER TABLE `cp_logging_toolbar_tabs` DISABLE KEYS */;
INSERT INTO `cp_logging_toolbar_tabs` VALUES (1,'Police','Preset','fas fa-siren-on',1,0),(2,'Fire + Rescue','Preset','fad fa-fire-alt',1,0),(3,'Ambulance / First-Aid','Preset','far fa-ambulance',1,0),(4,'Missing Lost Child or Vunerable','Preset','far fa-child',1,0),(5,'Security','Preset','far fa-cctv',1,0),(6,'Race Track','Custom','fas fa-flag-checkered',1,0),(7,'Ticketing','Preset','fal fa-ticket-alt',1,0),(8,'Food & Beverage','Preset','fad fa-burger-soda',1,0),(9,'Livestock','Custom','far fa-ram',1,1),(10,'Cruise Ship','Custom','fal fa-ship',1,1),(11,'Cleaning Services','Preset','fal fa-hand-sparkles',1,0),(12,'Electrical / Power','Custom','fal fa-outlet',1,1),(13,'Public Transport','Custom','fal fa-subway',1,1),(14,'Utility Management','Preset','far fa-tools',1,0),(15,'Air Traffic Control','Preset','far fa-plane-departure',1,0);
/*!40000 ALTER TABLE `cp_logging_toolbar_tabs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cp_organisations`
--

DROP TABLE IF EXISTS `cp_organisations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cp_organisations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `organisation_name` varchar(256) DEFAULT NULL,
  `organistaion_type` varchar(256) DEFAULT NULL,
  `organistaion_billing_status` int(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cp_organisations`
--

LOCK TABLES `cp_organisations` WRITE;
/*!40000 ALTER TABLE `cp_organisations` DISABLE KEYS */;
INSERT INTO `cp_organisations` VALUES (1,'I Need Helpers','Sole Trader',0);
/*!40000 ALTER TABLE `cp_organisations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cp_task_details`
--

DROP TABLE IF EXISTS `cp_task_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cp_task_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_task` int(11) DEFAULT NULL,
  `data_type` int(11) DEFAULT NULL COMMENT 'data_type = 1. id_user_assigned data_type = 2. id_team_assigned data_type = 3. task_name data_type = 4. task_description data_type = 5. privacy_type (0.Uset, 1.Private, 2.Public	) data_type = 6. status (1.created, 2.accepted, 3.declined, 4.completed) data_type = 7. task_deadline_date data_type = 8. task_deadline_time',
  `data` varchar(512) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cp_task_details`
--

LOCK TABLES `cp_task_details` WRITE;
/*!40000 ALTER TABLE `cp_task_details` DISABLE KEYS */;
INSERT INTO `cp_task_details` VALUES (1,1,6,'1','2020-04-12 14:08:25'),(2,1,3,'Test Task Name','2020-04-12 14:08:25'),(3,1,1,'10','2020-04-12 14:08:50'),(4,1,3,'New Test Task Name','2020-04-12 14:08:26'),(5,1,5,'2','2020-04-12 14:08:26'),(6,1,4,'Some description from DB','2020-04-12 14:08:26'),(7,1,7,'20-04-2020','2020-04-12 14:08:26'),(8,2,6,'4','2020-04-12 18:22:32'),(9,2,3,'Task Name','2020-04-12 14:08:25'),(10,2,1,'10','2020-04-12 14:08:50'),(11,2,5,'2','2020-04-12 14:08:26'),(12,2,4,'Task description','2020-04-12 14:08:26'),(13,2,7,'30-04-2020','2020-04-12 14:08:26');
/*!40000 ALTER TABLE `cp_task_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cp_tasks`
--

DROP TABLE IF EXISTS `cp_tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cp_tasks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user_assignee` int(11) DEFAULT NULL,
  `id_event` int(11) DEFAULT NULL,
  `id_incident` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cp_tasks`
--

LOCK TABLES `cp_tasks` WRITE;
/*!40000 ALTER TABLE `cp_tasks` DISABLE KEYS */;
INSERT INTO `cp_tasks` VALUES (1,1,1,1),(2,1,1,1);
/*!40000 ALTER TABLE `cp_tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cp_toolbar_event_tabs`
--

DROP TABLE IF EXISTS `cp_toolbar_event_tabs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cp_toolbar_event_tabs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tab_option` int(11) DEFAULT NULL,
  `id_event` int(11) DEFAULT NULL,
  `id_instance` int(11) DEFAULT NULL,
  `id_position` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cp_toolbar_event_tabs`
--

LOCK TABLES `cp_toolbar_event_tabs` WRITE;
/*!40000 ALTER TABLE `cp_toolbar_event_tabs` DISABLE KEYS */;
INSERT INTO `cp_toolbar_event_tabs` VALUES (1,1,0,0,1),(2,2,0,0,2),(3,3,0,0,3),(4,4,0,0,4),(5,5,0,0,5),(6,7,2,6,5),(18,15,2,6,4);
/*!40000 ALTER TABLE `cp_toolbar_event_tabs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cp_toolbar_tab_field_options`
--

DROP TABLE IF EXISTS `cp_toolbar_tab_field_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cp_toolbar_tab_field_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_field` int(11) DEFAULT NULL,
  `option_text` varchar(256) DEFAULT NULL,
  `option_status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cp_toolbar_tab_field_options`
--

LOCK TABLES `cp_toolbar_tab_field_options` WRITE;
/*!40000 ALTER TABLE `cp_toolbar_tab_field_options` DISABLE KEYS */;
INSERT INTO `cp_toolbar_tab_field_options` VALUES (1,3,'Aviation Support Branch (Air Wing)',1),(2,3,'Bicycle Unit',1),(3,3,'Dog Unit',1),(4,3,'Detectives',1),(5,3,'Forensic Services Group (FSG)',1),(6,3,'Highway Patrol',1),(7,3,'Marine Area Command',1),(8,3,'Mounted Police Unit',1),(9,3,'Operations Support Group (OSG)',1),(10,3,'Plain Clothed Officers',1),(11,3,'Police Negotiators',1),(12,3,'Protections Support Unit (SPSU)',1),(13,3,'Police Transport Command',1),(14,3,'Public Order Riot Squad (PORS)',1),(15,3,'Rescue & Bomb Disposal Unit (RBDU)',1),(16,3,'Tactical Operations Unit (TOU)',1),(17,8,'Yes',1),(18,8,'No',1),(19,8,'Unknown',1),(20,10,'Yes',1),(21,10,'No',1),(22,10,'Unknown',1),(23,15,'Yes',1),(24,15,'No',1),(25,15,'Unknown',1),(26,16,'Yes',1),(27,16,'No',1),(28,16,'Unknown',1),(29,17,'Yes',1),(30,17,'No',1),(31,17,'Unknown',1),(32,19,'Yes',1),(33,19,'No',1),(34,19,'Unknown',1),(35,26,'Aboriginal/Torres Strait Islander appearance',1),(36,26,'African appearance',1),(37,26,'Asian appearance',1),(38,26,'Caucasian appearance',1),(39,26,'Hispanic',1),(40,26,'Indian Sub-Continental appearance',1),(41,26,'Mediterranean / Middle Eastern appearance',1),(42,26,'Pacific Islander/Maori appearance',1),(43,26,'South American appearance',1),(44,31,'Yes',1),(45,31,'No',1),(46,31,'Unknown',1),(47,38,'1 - Urgent',1),(48,38,'2 - Immediate',1),(49,38,'3 - Non-Urgent',1),(50,38,'4 - Routine',1),(51,38,'5 - No Police Required',1);
/*!40000 ALTER TABLE `cp_toolbar_tab_field_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cp_toolbar_tab_fields`
--

DROP TABLE IF EXISTS `cp_toolbar_tab_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cp_toolbar_tab_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tab_option` int(11) DEFAULT NULL,
  `field_type` varchar(64) DEFAULT NULL,
  `fied_text` varchar(128) DEFAULT NULL,
  `field_placeholder` varchar(128) DEFAULT NULL,
  `field_status` int(1) DEFAULT NULL,
  `field_required` int(1) DEFAULT NULL,
  `field_order` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cp_toolbar_tab_fields`
--

LOCK TABLES `cp_toolbar_tab_fields` WRITE;
/*!40000 ALTER TABLE `cp_toolbar_tab_fields` DISABLE KEYS */;
INSERT INTO `cp_toolbar_tab_fields` VALUES (1,0,'text-area','Additional Information','Additional Information',1,0,100),(3,1,'multi-select','Specialist Unit(s) Required','',1,0,102),(4,1,'multi-agency-police','Multi-Agency Response',NULL,1,0,103),(5,1,'text-area','Additional Information','Other Information…',0,0,104),(7,2,'text-field','Hazards','Any hazards?',1,0,101),(8,2,'multi-button','HazMat Req',NULL,1,0,102),(9,2,'multi-agency-fire','Multi-Agency Response',NULL,1,0,103),(10,2,'multi-button','Emergency Services Contacted',NULL,1,0,104),(12,3,'text-field','Patient\'s Name','Patient\'s Name',1,0,1),(13,3,'age-field','Patient\'s Age',NULL,1,0,2),(14,3,'gender-field-extend','Patient\'s Sex',NULL,1,0,3),(15,3,'multi-button','Conscious',NULL,1,1,4),(16,3,'multi-button','Breathing',NULL,1,1,5),(17,3,'multi-button','Bleeding',NULL,1,1,6),(18,3,'multi-agency-ambulance','Multi-Agency Response',NULL,1,0,7),(19,3,'multi-button','Emergency Services Contacted',NULL,1,0,8),(20,3,'text-field','Hazards','Any hazards?',1,0,9),(22,4,'text-field','Person\'s Name','POI\'s name',1,0,1),(23,4,'age-field','Person\'s Age',NULL,1,0,2),(24,4,'gender-field-extend','Person\'s Sex',NULL,1,0,3),(25,4,'text-field','Clothing','ie. Jacket / pants etc',1,0,4),(26,4,'dropdown','Ethnicity',NULL,1,0,5),(27,4,'text-field','Height','ie. 170cm',1,0,6),(28,4,'text-field','Hair Colour','ie. Blond, ponytail',1,0,7),(29,4,'text-field','Eye Colour','ie. Brown',1,0,8),(30,4,'text-field','Carer\'s Details','Relationship & no.',1,0,9),(31,4,'multi-button','Carer Contacted',NULL,1,0,10),(34,5,'text-field','Hazards','Any hazards?',1,0,101),(36,6,'multi-button','Spill Kit Req',NULL,1,0,1),(37,6,'multi-agency','Agency Req',NULL,1,0,1),(38,1,'dropdown','Priority',NULL,1,0,101),(39,4,'age-field','Person\'s Age (2)',NULL,1,0,2);
/*!40000 ALTER TABLE `cp_toolbar_tab_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cp_toolbar_tab_type_options`
--

DROP TABLE IF EXISTS `cp_toolbar_tab_type_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cp_toolbar_tab_type_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tab` int(11) DEFAULT NULL,
  `option_text` varchar(256) DEFAULT NULL,
  `dispatch_type` int(1) DEFAULT NULL,
  `option_status` int(1) DEFAULT NULL,
  `id_location` int(11) DEFAULT NULL,
  `id_organisation` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=390 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cp_toolbar_tab_type_options`
--

LOCK TABLES `cp_toolbar_tab_type_options` WRITE;
/*!40000 ALTER TABLE `cp_toolbar_tab_type_options` DISABLE KEYS */;
INSERT INTO `cp_toolbar_tab_type_options` VALUES (1,1,'101 - Homicide',1,1,0,0),(2,1,'102 - Serious Assault',1,1,0,0),(3,1,'103 - Assault Other',1,1,0,0),(4,1,'104 - Abduction',1,1,0,0),(5,1,'105 - Offences against children',1,1,0,0),(6,1,'106 - Threats against persons',1,1,0,0),(7,1,'107 - Malicious phone calls',1,1,0,0),(8,1,'111 - Rape',1,1,0,0),(9,1,'112 - Attempted Rape',1,1,0,0),(10,1,'113 - Indecient Assault',1,1,0,0),(11,1,'114 - Wilful Exposure',1,1,0,0),(12,1,'115 - Indecent Act',1,1,0,0),(13,1,'121 - Armed Hold-Up',1,1,0,0),(14,1,'122 - Stealing with violence',1,1,0,0),(15,1,'123 - Stealing',1,1,0,0),(16,1,'124 - Shop Steal (Adult)',1,1,0,0),(17,1,'125 - Shop Steal (Minor)',1,1,0,0),(18,1,'126 - Fraud',1,1,0,0),(19,1,'127 - Unauthorised User Motor Car - Car Theft',1,1,0,0),(20,1,'131 - Breaker at Premises',1,1,0,0),(21,1,'132 - Alarm Activated',1,1,0,0),(22,1,'133 - Insceure Premises',1,1,0,0),(23,1,'134 - Break & Enter',1,1,0,0),(24,1,'135 - Wilful Damage',1,1,0,0),(25,1,'136 - Property Lost',1,1,0,0),(26,1,'137 - Property Found',1,1,0,0),(27,1,'141 - Poweler',1,1,0,0),(28,1,'142 - Trespass',1,1,0,0),(29,1,'143 - Suspect Loitering',1,1,0,0),(30,1,'201 - Motor Vehicle Accident (Car) - Fatal',1,1,0,0),(31,1,'202 - Motor Vehicle Accident (Car) - Hit & Run',1,1,0,0),(32,1,'203 - Motor Vehicle Accident (Car) - No Persons Injured',1,1,0,0),(33,1,'204 - Motor Vehicle Accident (Car) - Police Vehicle',1,1,0,0),(34,1,'205 - Motor Vehicle Accident (Car) - Injuries',1,1,0,0),(35,1,'206 - Train / Rail Accident',1,1,0,0),(36,1,'212 - Fare Evasion / Evader',1,1,0,0),(37,1,'213 - Under Influence Liquor (UIL)',1,1,0,0),(38,1,'214 - Traffic Offence',1,1,0,0),(39,1,'221 - Traffic Hazard',1,1,0,0),(40,1,'222 - Traffic Congestion',1,1,0,0),(41,1,'223 - Traffic Lights Out',1,1,0,0),(42,1,'224 - Abandoned Vehicle',1,1,0,0),(43,1,'225 - Suspect Vehicle',1,1,0,0),(44,1,'301 - Armed Persons',1,1,0,0),(45,1,'302 - Siege',1,1,0,0),(46,1,'303 - Shots Fired',1,1,0,0),(47,1,'304 - Hijack',1,1,0,0),(48,1,'305 - Hostage(s) Taken',1,1,0,0),(49,1,'311 - Noise Complaint',1,1,0,0),(50,1,'312 - Domestic',1,1,0,0),(51,1,'313 - Disturbance other than noise',1,1,0,0),(52,1,'314 - Drunk & Disorderly',1,1,0,0),(53,1,'315 - Street disturbance/demonstration',1,1,0,0),(54,1,'316 - Political disturbance/demonstration',1,1,0,0),(55,1,'317 - Industrial disturbance/picket line',1,1,0,0),(56,1,'Evading Police / Pursuit',2,1,0,0),(57,1,'#extrafield',2,0,0,0),(58,1,'#extrafield',2,0,0,0),(59,1,'#extrafield',2,0,0,0),(60,1,'#extrafield',2,0,0,0),(61,1,'#extrafield',2,0,0,0),(62,1,'BOLO - Be on the Lookout',1,1,0,0),(63,1,'401 - Fire - Building',1,1,0,0),(64,1,'402 - Fire - Vehicle',1,1,0,0),(65,1,'403 - Fire - Grass',1,1,0,0),(66,1,'404 - Fire - Other',1,1,0,0),(67,1,'411 - Explosion',1,1,0,0),(68,1,'412 - Bomb threat',1,1,0,0),(69,1,'413 - Explosive found',1,1,0,0),(70,1,'414 - Suspicious device found',1,1,0,0),(71,1,'421 - Spillage / Leak - Fuels (petrol, diesel, avgas, 2 stroke etc)',1,1,0,0),(72,1,'422 - Spillage / Leak - Chemical',1,1,0,0),(73,1,'423 - Spillage / Leak - Gases',1,1,0,0),(74,1,'431 - Aviation Incident',1,1,0,0),(75,1,'432 - Marine Incident',1,1,0,0),(76,1,'433 - Flare Sightings & Distress Signals',1,1,0,0),(77,1,'501 - Sudden Death',1,1,0,0),(78,1,'502 - Attempting/Attempted Suicide',1,1,0,0),(79,1,'503 - Person collapsed',1,1,0,0),(80,1,'504 - Mentally ill person',1,1,0,0),(81,1,'505 - Industrial accident',1,1,0,0),(82,1,'506 - Domestic accident',1,1,0,0),(83,1,'511 - Services Assist Medivac',1,1,0,0),(84,1,'512 - Services Assist Escort Ambulance',1,1,0,0),(85,1,'513 - Services Assist Escort other',1,1,0,0),(86,1,'514 - Services Assist Fire Brigade',1,1,0,0),(87,1,'515 - Services Assist Prisons',1,1,0,0),(88,1,'516 - Services Assist Natural Disaster',1,1,0,0),(89,1,'517 - Services Assist Search',1,1,0,0),(90,1,'518 - Services Assist Localised flooding',1,1,0,0),(91,1,'521 - Escapee Prison',1,1,0,0),(92,1,'522 - Escapee Mental Hospital/Hospital',1,1,0,0),(93,1,'523 - Escapee Juvenile',1,1,0,0),(94,1,'524 - Missing Persons',1,1,0,0),(95,1,'601 - Animal related',1,1,0,0),(96,1,'602 - Stock related',1,1,0,0),(97,1,'603 - Drug related',1,1,0,0),(98,1,'604 - Vice related',1,1,0,0),(99,1,'605 - Liquor Act offence',1,1,0,0),(100,1,'606 - Transport',1,1,0,0),(101,1,'607 - Message death or serious injury',1,1,0,0),(102,1,'608 - Message other',1,1,0,0),(103,1,'609 - Scene examination',1,1,0,0),(104,1,'610 - Community assistance',1,1,0,0),(105,1,'611 - Impersonate police',1,1,0,0),(106,1,'612 - Wanted suspect persons',1,1,0,0),(107,1,'613 - Civil matter',1,1,0,0),(108,1,'701 - Police In trouble ',1,1,0,0),(109,1,'Active Shooter',2,1,0,0),(110,1,'Active Siege / Hostage Situation',2,1,0,0),(111,1,'Animal Problem',2,1,0,0),(112,1,'Armed Offender/s',2,1,0,0),(113,1,'Arson',2,1,0,0),(114,1,'Assault',2,1,0,0),(115,1,'Attempted Auto Theft / Stolen Vehicle',2,1,0,0),(116,1,'Auto Theft',2,1,0,0),(117,1,'Barricaded Offender',2,1,0,0),(118,1,'Bomb Response and Disposal',2,1,0,0),(119,1,'Burglary Commercial / Non-residential',2,1,0,0),(120,1,'Burglary Commercial / Non-residential (In Progress)',2,1,0,0),(121,1,'Burglary Residential',2,1,0,0),(122,1,'Burglary Residential (In Progress)',2,1,0,0),(123,1,'Child Abuse / Neglect',2,1,0,0),(124,1,'Crowd Control',2,1,0,0),(125,1,'Deceased Person(s)',2,1,0,0),(126,1,'Disaster victim identification (DVI)',2,1,0,0),(127,1,'Disorderly Conduct',2,1,0,0),(128,1,'Knife / Stabbing Attack',2,1,0,0),(129,1,'Explosives',2,1,0,0),(130,1,'Extorsion / Blackmail',2,1,0,0),(131,1,'Fireworks',2,1,0,0),(132,1,'First response to chemical, biological or radiological incidents (CBR)',2,1,0,0),(133,1,'Forgery / Fraud',2,1,0,0),(134,1,'Found Child',2,1,0,0),(135,1,'Found Vulnerable Adult',2,1,0,0),(136,1,'General Rescue',2,1,0,0),(137,1,'Harassment',2,1,0,0),(138,1,'Homicide',2,1,0,0),(139,1,'Hostile Vehicle Attack',2,1,0,0),(140,1,'Illicit Activity',2,1,0,0),(141,1,'Intoxicated Persons',2,1,0,0),(142,1,'Kidnapping /Extortion',2,1,0,0),(143,1,'Land Search and Rescue',2,1,0,0),(144,1,'Littering / Pollution Problem',2,1,0,0),(145,1,'Luring',2,1,0,0),(146,1,'Missing Child',2,1,0,0),(147,1,'Missing Person',2,1,0,0),(148,1,'Missing Vulnerable Adult',2,1,0,0),(149,1,'Motor Vehicle (Car) / Traffic Accident',2,1,0,0),(150,1,'Noise Complaint',2,1,0,0),(151,1,'Personal Threat',2,1,0,0),(152,1,'Persons with mental health issues',2,1,0,0),(153,1,'Problem Behavour',2,1,0,0),(154,1,'Protest',2,1,0,0),(155,1,'Public Indecency',2,1,0,0),(156,1,'Robbery',2,1,0,0),(157,1,'Sex Offence',2,1,0,0),(158,1,'Specialist Support',2,1,0,0),(159,1,'Suicide intervention',2,1,0,0),(160,1,'Suspicious Activity',2,1,0,0),(161,1,'Suspicious Item / Package',2,1,0,0),(162,1,'Terrorism',2,1,0,0),(163,1,'Theft',2,1,0,0),(164,1,'Theft From Vehicle',2,1,0,0),(165,1,'Traffic / Road Incident',2,1,0,0),(166,1,'Traffic Signal Blackout',2,1,0,0),(167,1,'Tresspass',2,1,0,0),(168,1,'Unauthorised Drone Operation',2,1,0,0),(169,1,'Vandalism',2,1,0,0),(170,1,'Water Search and Rescue',2,1,0,0),(171,1,'Weapons Offence',2,1,0,0),(172,2,'Aircraft Emergency',1,1,0,0),(173,2,'Alarms Citizen Assist / Service Call',1,1,0,0),(174,2,'Confined Space / Structure Collapse',1,1,0,0),(175,2,'ElectricalHazard',1,1,0,0),(176,2,'Elevator / Escalator Rescue',1,1,0,0),(177,2,'Explosion',1,1,0,0),(178,2,'Extrication / Entrapped (Machinery, Vehcile)',1,1,0,0),(179,2,'Fuel / Petrol Spill',1,1,0,0),(180,2,'Gas Leak / Gas Odor (Natural and LP Gases)',1,1,0,0),(181,2,'HAZMAT',1,1,0,0),(182,2,'High Angle Rescue (Above or Below Grade)',1,1,0,0),(183,2,'Lightning Strike',1,1,0,0),(184,2,'Marine Fire',1,1,0,0),(185,2,'Mutual Aid / Assist Outside Agency',1,1,0,0),(186,2,'Odor (Strange / Unknown)',1,1,0,0),(187,2,'Outside Fire',1,1,0,0),(188,2,'Train and Rail Collision / Derailment',1,1,0,0),(189,2,'Vehcile Fire',1,1,0,0),(190,2,'Water Rescue',1,1,0,0),(191,2,'Watercraft in Distress',1,1,0,0),(192,2,'Suspicious Item / Bomb Threat',1,1,0,0),(193,2,'Train and Rail Fire',1,1,0,0),(194,2,'Building Fire',2,1,0,0),(195,2,'Building Alarm',2,1,0,0),(196,2,'Fire Alarm',2,1,0,0),(197,2,'Bin Fire',2,1,0,0),(198,2,'Roadside Fire',2,1,0,0),(199,2,'Person on Fire',2,1,0,0),(200,2,'Smoke',2,1,0,0),(201,2,'Infrastructure Fire',2,1,0,0),(202,2,'Rescue',2,1,0,0),(203,3,'Abdominal / Stomach Pain / Problems',1,1,0,0),(204,3,'Allergies (Reactions) / Envenomations (Stings, Bites)',1,1,0,0),(205,3,'Animal Bite / Sting / Attack',1,1,0,0),(206,3,'Assault / Sexual Assault / Stun Gun',1,1,0,0),(207,3,'Back Pain (Non-Traumatic / Non-Recent)',1,1,0,0),(208,3,'Breathing Problems',1,1,0,0),(209,3,'Burn (Scalds) / Explosion',1,1,0,0),(210,3,'Carbon Monoxide / Inhalation / HAZMAT / CBRN',1,1,0,0),(211,3,'Cardiac or Respiratory Arrest',1,1,0,0),(212,3,'Chest Pain',1,1,0,0),(213,3,'Choking',1,1,0,0),(214,3,'Convulsions / Seizures',1,1,0,0),(215,3,'Diabetic Problems',1,1,0,0),(216,3,'Drowning / Diving / SCUBA Accident',1,1,0,0),(217,3,'Electrocution / Lightning',1,1,0,0),(218,3,'Eye Problem / Injury',1,1,0,0),(219,3,'Fall',1,1,0,0),(220,3,'Headache',1,1,0,0),(221,3,'Heart Problems / A.I.C.D.',1,1,0,0),(222,3,'Heat / Cold Exposure',1,1,0,0),(223,3,'Hemorrhage / Lacerations',1,1,0,0),(224,3,'Inaccessible Incident / Entrapments',1,1,0,0),(225,3,'Overdose / Poisoning (Ingestion)',1,1,0,0),(226,3,'Pregnancy / Childbirth / Miscarriage',1,1,0,0),(227,3,'Psychiatric / Suicide Attempt',1,1,0,0),(228,3,'Sick Person',1,1,0,0),(229,3,'Stab / Gunshot / Penetrating Trauma',1,1,0,0),(230,3,'Stroke (CVA) / Transient Ischemic Attack (TIA)',1,1,0,0),(231,3,'Motor Vehicle (Car) / Traffic Accident',1,1,0,0),(232,3,'Traumatic Injuries',1,1,0,0),(233,3,'Unconscious / Fainting (Near)',1,1,0,0),(234,3,'Unknown Problem (Collapse Third Party)',1,1,0,0),(235,3,'Inter-Facility Transfer / Palliative Care',1,1,0,0),(236,3,'Automatic Crash Notification (A.C.N.)',1,1,0,0),(237,3,'HCP (Health-Care Practitioner) Referral',1,1,0,0),(238,3,'Pandemic / Epidemic / Outbreak (Surveillance or Triage)',1,1,0,0),(239,3,'Inter-Facility Transfer specific to medically trained callers',1,1,0,0),(240,3,'Altitude Sickness',2,1,0,0),(241,3,'Anaphylaxis (Allergic Reaction)',2,1,0,0),(242,3,'Arm Amputation (Digit Amputation / Fingers)',2,1,0,0),(243,3,'Arm Amputation (Metacarpal / Hand Below The Wrist)',2,1,0,0),(244,3,'Arm Amputation (Shoulder Disarticulation / Entire Arm)',2,1,0,0),(245,3,'Arm Amputation (Transhumeral / Above-elbow)',2,1,0,0),(246,3,'Arm Amputation (Transradial  / Forearm)',2,1,0,0),(247,3,'Arm Amputation (Wrist Disarticulation / Hand Including The Wrist)',2,1,0,0),(248,3,'Asthma Attack ',2,1,0,0),(249,3,'Bleeding / Laceration / Abrasion',2,1,0,0),(250,3,'Bone Fracture',2,1,0,0),(251,3,'Broken Bone',2,1,0,0),(252,3,'Burn (Thermal)',2,1,0,0),(253,3,'Burn (Chemical / Acid)',2,1,0,0),(254,3,'Burn (Electrical)',2,1,0,0),(255,3,'Burn (Friction)',2,1,0,0),(256,3,'Slip / Trip / Fall',2,1,0,0),(257,3,'Fall From Height',2,1,0,0),(258,3,'Brawl / Assult Injuries',2,1,0,0),(259,3,'Feeling Unwell',2,1,0,0),(260,3,'Plant / Machinery Injury',2,1,0,0),(261,3,'Crush Injury',2,1,0,0),(262,3,'Dehydration ',2,1,0,0),(263,3,'Dislocation (Elbow - Posterior Dislocation)',2,1,0,0),(264,3,'Dislocation (Finger - Interphalangeal (Ip) / Metacarpophalangeal Dislocation)',2,1,0,0),(265,3,'Dislocation (Foot / Ankle - Lisfranc Injury)',2,1,0,0),(266,3,'Dislocation (Hip - Posterior / Anterior Dislocation)',2,1,0,0),(267,3,'Dislocation (Knee - Acute Traumatic Patellar Dislocation)',2,1,0,0),(268,3,'Dislocation (Shoulder - Anterior Dislocation)',2,1,0,0),(269,3,'Dislocation (Wrist - Lunate / Perilunate Dislocation)',2,1,0,0),(270,3,'Diving Injury (General)',2,1,0,0),(271,3,'Diving Injury (Pulmonary Barotrauma / Lung Overexpansion)',2,1,0,0),(272,3,'Diving Injury (Decompression Sickness)',2,1,0,0),(273,3,'Diving Injury (Non-fatal Drowning)',2,1,0,0),(274,3,'Drowning (Wet Drowning - Fluid In Lungs)',2,1,0,0),(275,3,'Drowning (Dry Drowning - Secondary Drowning)',2,1,0,0),(276,3,'Asphyxiation (Physical: Force / Object)',2,1,0,0),(277,3,'Asphyxiation (Choking)',2,1,0,0),(278,3,'Asphyxiation (Suffocation)',2,1,0,0),(279,3,'Asphyxiation (Strangulation)',2,1,0,0),(280,3,'Asphyxiation (Chemical)',2,1,0,0),(281,3,'Asphyxiation (Drug)',2,1,0,0),(282,3,'Asphyxiation (Self)',2,1,0,0),(283,3,'Drug Overdose',2,1,0,0),(284,3,'Drug / Alcohol Withdrawal',2,1,0,0),(285,3,'Intoxication / Alcohol Impaired',2,1,0,0),(286,3,'Dysmenorrhea (Menstrual Cramps)',2,1,0,0),(287,3,'Testicular Torsion',2,1,0,0),(288,3,'Electrocution',2,1,0,0),(289,3,'Eye Injury (General)',2,1,0,0),(290,3,'Eye Injury (Cut Or Scratch Of Eyelid)',2,1,0,0),(291,3,'Eye Injury (General)',2,1,0,0),(292,3,'Eye Injury (Corneal Abrasion - Scratch To The Clear Part Of The Eye)',2,1,0,0),(293,3,'Eye Injury (Acute Hyphema - Bleeding Between Cornea And Iris)',2,1,0,0),(294,3,'Eye Injury (Punctured Eyeball)',2,1,0,0),(295,3,'Eye Injury (Chemical)',2,1,0,0),(296,3,'Foot Amputation (Ankle Disarticulation / Foot Including The Ankle)',2,1,0,0),(297,3,'Foot Amputation (Digit Amputation / Toes)',2,1,0,0),(298,3,'Foot Amputation (Foot Below The Ankle)',2,1,0,0),(299,3,'Gunshot Wound',2,1,0,0),(300,3,'Hair Tourniquet',2,1,0,0),(301,3,'Head Injury',2,1,0,0),(302,3,'Heat Stroke ',2,1,0,0),(303,3,'Heat Syncope / Orthostatic Dizziness / Heat Exhaustion ',2,1,0,0),(304,3,'Hyperglycemia (Diabetic Coma)',2,1,0,0),(305,3,'Hyperthermia (Overheating)',2,1,0,0),(306,3,'Hypothermia (Low Body Temperature)',2,1,0,0),(307,3,'Hypoglycemia (Insulin Shock)',2,1,0,0),(308,3,'Leg Amputation (Hip Disarticulation / Entire Leg And Hip Joint)',2,1,0,0),(309,3,'Leg Amputation (Knee Disarticulation / Leg Including The Knee)',2,1,0,0),(310,3,'Leg Amputation (Transfemoral / Leg Above The Knee)',2,1,0,0),(311,3,'Leg Amputation (Transtibial Amputation / Leg Below The Knee)',2,1,0,0),(312,3,'Muscle Strain (Back)',2,1,0,0),(313,3,'Muscle Strain (Elbow)',2,1,0,0),(314,3,'Muscle Strain (Forearm)',2,1,0,0),(315,3,'Muscle Strain (Hamstring)',2,1,0,0),(316,3,'Muscle Strain (Hamstring)',2,1,0,0),(317,3,'Muscle Strain (Hand / Wrist)',2,1,0,0),(318,3,'Muscle Strain (Shoulder)',2,1,0,0),(319,3,'Pelvic Injury',2,1,0,0),(320,3,'Poisoning (Absorption)',2,1,0,0),(321,3,'Poisoning (Ingestion)',2,1,0,0),(322,3,'Poisoning (Inhalation)',2,1,0,0),(323,3,'Poisoning (Injection)',2,1,0,0),(324,3,'Seizure / Fit (Grand Mal - Convulsions)',2,1,0,0),(325,3,'Seizure / Fit (Petit Mal - Twitching / Rapid Blinking)',2,1,0,0),(326,3,'Shrapnel Damage',2,1,0,0),(327,3,'Smoke Inhalation',2,1,0,0),(328,3,'Sunstroke',2,1,0,0),(329,3,'Suspected Spinal Injury',2,1,0,0),(330,3,'Toothache',2,1,0,0),(331,3,'Trapped Casualty',2,1,0,0),(332,3,'Unconscious',2,1,0,0),(333,3,'Puncture Wound (Knife / Stab Wound)',2,1,0,0),(334,3,'Puncture Wound',2,1,0,0),(335,3,'Panic Disorder (Panic Attack)',2,1,0,0),(336,4,'Missing Child',1,1,0,0),(337,4,'Missing Vulnerable Adult',1,1,0,0),(338,4,'Unattended Child',1,1,0,0),(339,4,'Unattended Vulnerable Adult',1,1,0,0),(340,5,'Arson',2,1,0,0),(341,5,'Assault',2,1,0,0),(342,5,'Crowd Congestion',2,1,0,0),(343,5,'Crowd Issue (Unsafe, Uncontrolled, And/ Rowdy Behavior)',2,1,0,0),(344,5,'Disorderly Patron',2,1,0,0),(345,5,'Fireworks',2,1,0,0),(346,5,'Found Child',2,1,0,0),(347,5,'Found Vulnerable Adult',2,1,0,0),(348,5,'Illicit Activity',2,1,0,0),(349,5,'Intoxicated Persons',2,1,0,0),(350,5,'Missing Child',2,1,0,0),(351,5,'Missing Vulnerable Adult',2,1,0,0),(352,5,'Problem Behavour',2,1,0,0),(353,5,'Property Damage',2,1,0,0),(354,5,'Protest',2,1,0,0),(355,5,'Public Blocking Emergency Exits',2,1,0,0),(356,5,'Refusal To Cooperate With Security Requests',2,1,0,0),(357,5,'Sex Offence',2,1,0,0),(358,5,'Suspicious Activity',2,1,0,0),(359,5,'Theft',2,1,0,0),(360,5,'Ticket Scalping',2,1,0,0),(361,5,'Trespass',2,1,0,0),(362,5,'Unathorised Video / Audio Recording',2,1,0,0),(363,5,'Unauthorised Access (Entering Without Ticket / Credential)',2,1,0,0),(364,5,'Unauthorised Drone Operation',2,1,0,0),(365,6,'Person on track',1,1,0,0),(366,6,'Debris on track',1,1,0,0),(367,6,'Petrol spill',1,1,0,0),(368,6,'Barrier Collision / Damage',1,1,0,0),(369,11,'Waste Disposal',1,1,0,0),(370,11,'Body Fluids (vomit)',1,1,0,0),(371,11,'Body Fluids (faeces)',1,1,0,0),(372,11,'Body Fluids (blood)',1,1,0,0),(373,11,'Body Fluids (urine)',1,1,0,0),(374,11,'Sweeping',1,1,0,0),(375,11,'Mopping',1,1,0,0),(376,11,'Overflowing/Full Bins',1,1,0,0),(377,11,'Broken Glass',1,1,0,0),(378,11,'Hazardous Chemicals',1,1,0,0),(379,15,'Air Alert 1 - Aircraft Standby',1,1,0,0),(380,15,'Air Alert 2 - Aircraft Emergency Standby',1,1,0,0),(381,15,'Air Alert 3 - Aircraft Emergency',1,1,0,0),(382,15,'Flight control system malfunction or failure',1,1,0,0),(383,15,'Evacuation of Aircraft',1,1,0,0),(384,15,'Runway Lighting Issue',1,1,0,0),(385,15,'Foreign Object Debris (FOD)',1,1,0,0),(386,15,'Aircraft Rescue and Fire Fighting (ARFF)',1,1,0,0),(387,15,'Vehicle Collision',1,1,0,0),(388,15,'Runway Closure',1,1,0,0),(389,5,'Armed Offender/s',2,1,0,0);
/*!40000 ALTER TABLE `cp_toolbar_tab_type_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cp_training_modules`
--

DROP TABLE IF EXISTS `cp_training_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cp_training_modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version_number` varchar(10) DEFAULT NULL,
  `scorm_link` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cp_training_modules`
--

LOCK TABLES `cp_training_modules` WRITE;
/*!40000 ALTER TABLE `cp_training_modules` DISABLE KEYS */;
INSERT INTO `cp_training_modules` VALUES (1,'13.5.0','test.com'),(2,'13.5.1','test.com');
/*!40000 ALTER TABLE `cp_training_modules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cp_users`
--

DROP TABLE IF EXISTS `cp_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cp_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_first_name` varchar(128) DEFAULT NULL,
  `user_last_name` varchar(128) DEFAULT NULL,
  `user_role` varchar(128) DEFAULT NULL,
  `user_company` varchar(128) DEFAULT NULL,
  `user_contact_number` varchar(128) DEFAULT NULL,
  `user_email` varchar(128) DEFAULT NULL,
  `user_password` varchar(256) DEFAULT NULL,
  `user_active` int(1) DEFAULT '0' COMMENT '0 = Import 1 = Pending 2 = Active 3 = Deactivated 4 = Disabled 5 = Removed from server',
  `user_token` varchar(256) DEFAULT NULL,
  `user_login_token` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cp_users`
--

LOCK TABLES `cp_users` WRITE;
/*!40000 ALTER TABLE `cp_users` DISABLE KEYS */;
INSERT INTO `cp_users` VALUES (1,'Alex','Rixon-Booth','Director','I Need Helpers','0421441501','admin@ineedhelpers.com','$2y$10$IYWJbbKdvEjmRmR54aKkG.yB5cCLnJ0qDe5OpUZWLJbsmgab7va3e',1,'h234i301mdbgd6','7e29068ed6ed3073'),(10,'Konstantin','Uvarov','Developer','ukas','61421441501','ukas.ru@gmail.com','$2y$10$/.7kzFsN8e/67gHZX8zln.5lWs8AC7wC580y4B5faA.uWD7nN908u',2,'5bb7e0f5b49baeb5','6625ea8a6bcf67c3');
/*!40000 ALTER TABLE `cp_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cp_users_training_record`
--

DROP TABLE IF EXISTS `cp_users_training_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cp_users_training_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) DEFAULT NULL,
  `id_module` int(11) DEFAULT NULL,
  `completion_date` datetime DEFAULT NULL,
  `id_event` int(11) DEFAULT NULL COMMENT 'Analytics, comms and billing ',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cp_users_training_record`
--

LOCK TABLES `cp_users_training_record` WRITE;
/*!40000 ALTER TABLE `cp_users_training_record` DISABLE KEYS */;
INSERT INTO `cp_users_training_record` VALUES (1,1,2,'2020-04-06 00:00:00',1),(2,2,2,'2020-04-06 00:00:00',1);
/*!40000 ALTER TABLE `cp_users_training_record` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-28 17:46:09

